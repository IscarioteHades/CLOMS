# CLOMS

説明
CLMOS
[Comprehensive Life Management of Support ]

仕様
UNIPAとManabaを統合して、課題管理や体調管理表の提出を自動化するマクロを備えたシステム

作成内容
・課題のリマインド
・体調管理表
・Yahooカレンダーとの連携